Use the images to create custom header module like on our demo.
If you don't know how to create custom module, read the article:
http://docs.joomla.org/How_do_you_create_a_custom_module%3F